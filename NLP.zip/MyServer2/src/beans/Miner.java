package beans;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.JSONOutputter;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

public class Miner {
	static StanfordCoreNLP pipeline;
	
	public Miner(){
		super();
		initializeCoreNLP();
	}
	
	HashMap<String,String> tableMap= new HashMap<String, String>();
	
	public void initializeCoreNLP() {  
        Properties props = new Properties();
        props.put("annotators", "tokenize,ssplit, pos, lemma, ner, parse");
        pipeline = new StanfordCoreNLP(props);
        
        tableMap.put("balance", "user_details");
        tableMap.put("transaction", "transactions");
        tableMap.put("plan", "plans");
        tableMap.put("promotion", "promotions");
        tableMap.put("offer", "promotions");
    }
	
	public static JSONArray getTokens(String text) throws JSONException, IOException{
		
		Annotation document = new Annotation(text);
		// run all Annotators on this text
		pipeline.annotate(document);
		
		//System.out.println(JSONOutputter.jsonPrint(document));
		String jsonString = JSONOutputter.jsonPrint(document);
		
		JSONObject obj = new JSONObject(jsonString);
		JSONArray sentences = obj.getJSONArray("sentences");
		JSONArray tokens = ((JSONObject)sentences.get(0)).getJSONArray("tokens");
		
		return tokens;
	}
	
}
