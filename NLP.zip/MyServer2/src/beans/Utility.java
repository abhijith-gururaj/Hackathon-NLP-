package beans;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import oracle.jdbc.driver.OracleDriver;

public class Utility {
	
	Driver d = new OracleDriver();
	static String url = "jdbc:oracle:thin:@localhost:1521:xe";
	static String user="system";
	static String pass = "password";
	
	public String getUserName(int userId){
		
		try {
			Connection conn = DriverManager.getConnection(url,user,pass);
			String query = "SELECT NAME FROM USER_DETAILS WHERE ID="+userId;
			
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
				return rs.getString(1);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
}
