package beans;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import oracle.jdbc.driver.OracleDriver;

public class ParseAlgo {


	Driver d = new OracleDriver();
	static String url = "jdbc:oracle:thin:@localhost:1521:xe";
	static String user="system";
	static String pass = "password";
	Miner miner;
	
	public ParseAlgo(){
		super();
		miner = new Miner();
	}
	
	static HashMap<String,String> tableMap= new HashMap<String, String>();

	public String doStuff(String id,String text) throws JSONException {


		// TODO Auto-generated method stub
		tableMap.put("balance", "user_details");
		tableMap.put("transaction", "transactions");
		tableMap.put("plan", "plan");
		tableMap.put("promotion", "promotions");
		tableMap.put("offer", "promotions");
		tableMap.put("call", "call_details");
		String response="";

		JSONArray tokens;
		try {
			int userId = Integer.parseInt(id);
			
			Connection conn = DriverManager.getConnection(url,user,pass);

			tokens = miner.getTokens(text);

			String noun="",jj="";
			System.out.println(tokens);
			float cd = 0.0f;
			boolean nounFlag = false,cdFlag = false,jjFlag=false;
			String dateClause="";
			boolean found = true;

			for(int i=0; i < tokens.length(); i++){
				JSONObject obj = tokens.getJSONObject(i);
				System.out.println(obj.get("pos"));

				if(obj.getString("pos").equalsIgnoreCase("NN")||obj.getString("pos").equalsIgnoreCase("NNS")){
					String lemma = obj.getString("lemma");
					switch(lemma){
					case "balance":
						noun = "balance";
						found = true;
						nounFlag = true;
						break;
					case "amount":
						noun = "balance";
						found = true;
						nounFlag = true;
						break;
					case "transaction":
						System.out.println(obj.get("lemma"));
						nounFlag = true;
						found = true;
						noun = "transaction";
						dateClause = "DATE_TRANSAC";
						break;
					case "payment":
						nounFlag = true;
						found = true;
						noun = "transaction";
						dateClause = "DATE_TRANSAC";
						break;
					case "promotion":
						nounFlag = true;
						found = true;
						noun = "promotion";
						break;
					case "offer":
						noun = "offer";
						found = true;
						nounFlag = true;
						break;
					case "plan":
						noun = "plan";
						found = true;
						nounFlag = true;
						break;
					case "call":
						noun = "call";
						found = true;
						nounFlag= true;
						break;
					case "conversation":
						noun = "call";
						found = true;
						nounFlag= true;
						break;
					default:
						found = false;
					}

				}
			}
			
			if(!found)
				return "I can't do that at the moment. Maybe type something else?";
			
			if(noun.equalsIgnoreCase("transaction")){
				for(int i=0; i < tokens.length(); i++){
					JSONObject obj = tokens.getJSONObject(i);
					if(obj.getString("pos").equalsIgnoreCase("CD")){
						cdFlag = true;
						cd = Float.parseFloat(obj.getString("normalizedNER"));

					}
				}
		
				
				if(cdFlag){
					for(int i=0; i < tokens.length(); i++){
						JSONObject obj = tokens.getJSONObject(i);
						if(obj.getString("pos").equalsIgnoreCase("JJ")){
							jjFlag = true;
							jj = obj.getString("lemma");
						}
					}
				}
				
			}
			
			if(noun.equalsIgnoreCase("plan")){
				for(int i=0; i < tokens.length(); i++){
					JSONObject obj = tokens.getJSONObject(i);
					if(obj.getString("pos").equalsIgnoreCase("JJ")){
						jjFlag = true;
						jj = obj.getString("lemma");
					}
				}
			}
			
			System.out.println("nn: "+nounFlag+" cd: "+cdFlag+" jj: "+jjFlag);
			System.out.println("n: "+noun+" cd: "+cd+"  jj: "+jj);

			String table = tableMap.get(noun);
			String query = "";
			
			if(noun.equals("balance")){
				query = "select NAME,MOBILE_NO,BALANCE FROM "+table+" WHERE ID="+id;
			}else if(noun.equals("transaction")){
				query = "select * from " + table+" where id="+id;
				for(int i=0; i < tokens.length(); i++){
					JSONObject obj = tokens.getJSONObject(i);
					if(obj.getString("pos").equalsIgnoreCase("JJ")){
						jjFlag = true;
						jj = obj.getString("lemma");
					}
				}
				if(jjFlag)
					query = "select * from ( select * from "+table+" where id="+id+" order by "+dateClause+" ASC ) where ROWNUM <= 1";
			}else if(noun.equals("promotion")){
				query="select PROMO_CODE, PROMO_DESC FROM PROMOTIONS WHERE promotions.plan_id in "+
			" (select plan_id from user_details where id="+id+")";
			}else if(noun.equals("call")){
				query = "select * from call_details where call_details.from_no in (select mobile_no from user_details where id="+id+
						") union select * from call_details where call_details.to_no in (select mobile_no from user_details where id="+id+")";
			}else
				query = "select * from "+table;

			int retval = Float.compare(cd, 0.0f);

			if(retval >0&&jjFlag){
				System.out.println("lol");
				if(jj.equalsIgnoreCase("last"))
					query = "select * from ( select * from "+table+" where id="+id+" order by "+dateClause+" DESC ) where ROWNUM <= "+(int)cd;
				else if(jj.equalsIgnoreCase("first"))
					query = "select * from ( select * from "+table+" where id="+id+" order by "+dateClause+" ASC ) where ROWNUM <= "+cd;
				else 
					query = "select * from ( select * from "+table+" where id="+id+" order by "+dateClause+" DESC ) where ROWNUM <= "+(int)cd;
			}else if(jjFlag&&noun.equalsIgnoreCase("plan")){
				query="select * from plan where plan_id in ( select plan_id from user_details where id = "+id+")";
			}

			System.out.println("The query is: "+query);
			PreparedStatement ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			
			response = "<table class='table table-bordered'>";
			response+="<tr>";
			for(int i =1;i<=columnCount;i++){
				
				response += "<th>"+rsmd.getColumnName(i)+"</th>";
				
			}
			response+="</tr>";
			response +="\n";
			while(rs.next()){
				response+="<tr>";
				for(int i =1;i<=columnCount;i++){
					//System.out.print(rs.getString(rsmd.getColumnName(i))+"     ");
					response += "<td>"+rs.getString(rsmd.getColumnName(i))+"</td>";
				}
				response += "</tr>";
			}
			System.out.println("Response: \n"+response);
			
			//again();
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response +="</table>";
		
		return response;
	}
}
